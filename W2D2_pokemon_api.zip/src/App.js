
import './App.css';
import React, {useState} from 'react';


function App() {

  const [pokemons, setPokemons] = useState([])

  const getPokemons = () =>{
    fetch("https://pokeapi.co/api/v2/pokemon?limit=100")
    .then(res => {
      return res.json();
  }).then(jRes => {
      console.log(jRes);
      setPokemons(jRes.results);
  }).catch(err=>{
      console.log(err => console.log(err));
  })
  }
  return (
    <div className="App">
      <h2>Pokemon</h2>
      
      <button onClick={getPokemons}>Get Pokemon</button>

      <hr />
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>URL</th>
          </tr>
        </thead>
        <tbody>
          {
            pokemons.map((pokemon, idx) => {
            return (
              <tr key={idx}>
                <td>{pokemon.name}</td>
                <td>{pokemon.url}</td>
              </tr>
            )
          })
        }
        </tbody>
      </table>
    </div>
  );
}

export default App;
